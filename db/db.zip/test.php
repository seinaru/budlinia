<div class="cat_list">
    <ul>
        <li><a href="/"><b>Кровля</b></a></li>
        <li><a href="/">Шифер</a></li>
        <li><a href="/">Ондулин</a></li>
        <li><a href="/">Рубероид</a></li>
        <li><a href="/">Черепиця</a></li>
        <li><a href="/">Ленты герметизирующие</a></li>
        <li><a href="/">Комплектующие</a></li>
        <li><a href="/">Мастики</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Изоляционые материалы</b></a></li>
        <li><a href="/">Пенопласт</a></li>
        <li><a href="/">Пленки</a></li>
        <li><a href="/">Подложка</a></li>
        <li><a href="/">Экструдированый пенопласт</a></li>
        <li><a href="/">Теплоизоляция</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Древестный материал</b></a></li>
        <li><a href="/">Брус</a></li>
        <li><a href="/">Фанера</a></li>
        <li><a href="/">OSB</a></li>
        <li><a href="/">ДСП</a></li>
        <li><a href="/">ДВП</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Сайдинг</b></a></li>
        <li><a href="/">Сайдинг</a></li>
        <li><a href="/">Комплектующие</a></li>
        <li><a href="/">Софит</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Крепежи</b> </a></li>
        <li><a href="/">Саморезы</a></li>
        <li><a href="/">Дюбеля</a></li>
        <li><a href="/">Анкера</a></li>
        <li><a href="/">Метизы</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Металоизделия</b></a></li>
        <li><a href="/">Сетка рабица</a></li>
        <li><a href="/">Сетка сварная</a></li>
        <li><a href="/">Сетка кладочная</a></li>
        <li><a href="/">Лист оцинкованый</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Кладочные материалы</b></a></li>
        <li><a href="/">Кирпич</a></li>
        <li><a href="/">Блоки</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Бетоные изделия</b></a></li>
        <li><a href="/">Ланшафтные изделия</a></li>
    </ul>
    <ul>
        <li><a href="/"><b>Водосточная система</b></a></li>
        <li><a href="/">Водосточная система</a></li>
    </ul>
</div>