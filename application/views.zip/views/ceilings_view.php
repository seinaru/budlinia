<?php

Model::displayGoods('Ceilings','decorationmaterials');