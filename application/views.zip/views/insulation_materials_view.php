<?php

Model::displayGoods('Insulation materials','buildingmaterials');