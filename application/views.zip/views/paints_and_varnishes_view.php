<?php



Model::displayGoods('Paints and varnishes','decorationmaterials');