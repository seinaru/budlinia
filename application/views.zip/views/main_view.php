<div class="slider">
    <a href="index.php"><img src="img/Vse_dlya_stroyki.jpg"></a>
</div>
<table width="100%" class="topTable">
    <caption ><b>ПОПУЛЯРНЫЕ ГРУППЫ ТОВАРОВ</b></caption>
    <tr>

        <td></td>
        <td><a href="/"><img src="">Утепление</a> </td>
        <td></td>
        <td><a href="/"><img src="">Клей</a></td>
        <td></td>
        <td><a href="/"><img src="">Плитка</a></td>
        <td></td>
    </tr>
</table>