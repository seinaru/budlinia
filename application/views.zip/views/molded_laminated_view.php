<?php


Model::displayGoods('Molded laminated','decorationmaterials');