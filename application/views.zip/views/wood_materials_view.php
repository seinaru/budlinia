<?php

Model::displayGoods('wood_materials','buildingmaterials');