<?php

Model::displayGoods('Building mixture','decorationmaterials');
