<?php

Model::displayGoods('Clay','decorationmaterials');