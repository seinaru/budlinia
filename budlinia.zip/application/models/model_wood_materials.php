<?php



class Model_Wood_materials extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
