<?php


class Model_Paints_and_varnishes extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
