<?php


class Model_Ceilings extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
