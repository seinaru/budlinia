<?php

class Model_Fiberglass extends Model
{

}
