<?php


class Model_Siding extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
