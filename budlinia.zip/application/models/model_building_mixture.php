<?php



class Model_Building_mixture extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
