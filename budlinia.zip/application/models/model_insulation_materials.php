<?php

class Model_Insulation_materials extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
