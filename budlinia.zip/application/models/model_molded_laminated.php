<?php



class Model_Molded_laminated extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
