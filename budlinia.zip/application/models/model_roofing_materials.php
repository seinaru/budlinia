<?php


class Model_Roofing_materials extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}

