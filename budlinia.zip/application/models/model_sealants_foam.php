<?php




class Model_Sealants_foam extends Model
{
    function __construct() {
        self::pdoConnect();
    }
}
