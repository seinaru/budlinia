<?php
$params = Model::pageParam();
Model::displayGoods('wood_materials','buildingmaterials',$params);