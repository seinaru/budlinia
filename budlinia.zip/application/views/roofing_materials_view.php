<?php
//global $params;
$params = Model::pageParam();

Model::displayGoods('Roofing materials','buildingmaterials',$params);
