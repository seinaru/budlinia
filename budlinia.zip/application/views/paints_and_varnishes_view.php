<?php


$params = Model::pageParam();

Model::displayGoods('Paints and varnishes','decorationmaterials',$params);