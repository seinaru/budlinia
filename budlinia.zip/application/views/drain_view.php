<?php

$params = Model::pageParam();
Model::displayGoods('Drain','buildingmaterials',$params);