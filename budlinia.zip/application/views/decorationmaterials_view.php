<div class="bud">
    <?php
    $dir = 'decorationmaterials';
    Model::full_list($data[0],$data[1],$dir, 6);
    ?>
    <br>
</div>
