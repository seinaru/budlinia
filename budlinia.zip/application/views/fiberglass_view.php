<?php
$params = Model::pageParam();

Model::displayGoods('fiberglass','decorationmaterials',$params);