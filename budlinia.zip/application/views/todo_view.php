<p align="middle">
    <img src="/images/zakr.jpg" width="50%" height="20%">
</p>
