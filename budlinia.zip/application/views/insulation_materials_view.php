<?php
$params = Model::pageParam();

Model::displayGoods('Insulation materials','buildingmaterials',$params);