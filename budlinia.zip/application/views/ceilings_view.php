<?php
$params = Model::pageParam();
Model::displayGoods('Ceilings','decorationmaterials',$params);