<?php
$params = Model::pageParam();

Model::displayGoods('Hardware','buildingmaterials',$params);