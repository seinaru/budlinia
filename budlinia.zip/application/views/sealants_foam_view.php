<?php
$params = Model::pageParam();

Model::displayGoods('Sealants, foam','decorationmaterials',$params);