<?php

$params = Model::pageParam();
Model::displayGoods('Building mixture','decorationmaterials',$params);
