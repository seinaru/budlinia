<?php
$params = Model::pageParam();
Model::displayGoods('Loose materials','buildingmaterials',$params);

