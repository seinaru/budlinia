<?php
$params = Model::pageParam();

Model::displayGoods('Molded laminated','decorationmaterials',$params);