<div class="bud">
<?php
$dir = 'buildingmaterials';
Model::full_list($data[0],$data[1],$dir, 7);
?>
    <br>
</div>
