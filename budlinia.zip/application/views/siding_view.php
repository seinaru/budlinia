<?php

$params = Model::pageParam();

Model::displayGoods('Siding','buildingmaterials',$params);