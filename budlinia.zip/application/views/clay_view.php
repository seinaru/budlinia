<?php
$params = Model::pageParam();
Model::displayGoods('Clay','decorationmaterials',$params);